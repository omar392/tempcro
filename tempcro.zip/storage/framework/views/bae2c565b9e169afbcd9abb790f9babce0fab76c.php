        <!-- Start Navbar Area -->
        <div class="navbar-area">
            <div class="mobile-responsive-nav">
                <div class="container-fluid">
                    <div class="mobile-responsive-menu">
                        <div class="logo">
                            <a href="<?php echo e(route('front.home')); ?>">
                                <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-one" alt="logo">
                                <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-two" alt="Logo">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Menu For Desktop Device -->
            <div class="desktop-nav desktop-nav-one nav-area">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="<?php echo e(route('front.home')); ?>">
                            <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-one" alt="Logo">
                            <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-two" alt="Logo">
                        </a>
                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <?php if(app()->getLocale() == 'ar'): ?>
                            <ul class="navbar-nav" style="margin-left: 253px;">
                            <?php endif; ?>
                            <?php if(app()->getLocale() == 'en'): ?>
                            <ul class="navbar-nav">
                            <?php endif; ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.home')); ?>"
                                        class="nav-link <?php echo e(URL::route('front.home') === URL::current() ? 'active' : ''); ?>">
                                        <?php echo e(__('site.home')); ?>

                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.about')); ?>"
                                        class="nav-link <?php echo e(URL::route('front.about') === URL::current() ? 'active' : ''); ?>">
                                        <?php echo e(__('site.about')); ?>

                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.services')); ?>"
                                        class="nav-link <?php echo e(URL::route('front.services') === URL::current() ? 'active' : ''); ?>">
                                        <?php echo e(__('site.services')); ?>

                                        <i class="ri-arrow-down-s-line"></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>"
                                                    class="nav-link">
                                                    <?php echo e($item->title); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#"
                                        class="nav-link <?php echo e(URL::route('front.blog') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.gallery') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.faqs') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.news') === URL::current() ? 'active' : ''); ?>">
                                        <?php echo e(__('site.pages')); ?>

                                        <i class="ri-arrow-down-s-line"></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.blog')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.blog') === URL::current() ? 'active' : ''); ?>">
                                                <?php echo e(__('site.blog')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.faqs')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.faqs') === URL::current() ? 'active' : ''); ?>">
                                                <?php echo e(__('site.faq')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.news')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.news') === URL::current() ? 'active' : ''); ?>">
                                                <?php echo e(__('site.news')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.gallery')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.gallery') === URL::current() ? 'active' : ''); ?>">
                                                <?php echo e(__('site.gallery')); ?>

                                            </a>
                                        </li>
                                    </ul>
                                </li>


                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.contact')); ?>"
                                        class="nav-link <?php echo e(URL::route('front.contact') === URL::current() ? 'active' : ''); ?>">
                                        <?php echo e(__('site.contact')); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($localeCode == LaravelLocalization::getCurrentLocale()): ?>
                                        <?php elseif($url = LaravelLocalization::getLocalizedURL($localeCode)): ?>
                                            <a href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                                                class="flag-bar">
                                                <?php if(app()->getLocale() == 'ar'): ?>
                                                    <span><b>English</b></span>
                                                <?php else: ?>
                                                    <span><b>العربية</b></span>
                                                <?php endif; ?>
                                            </a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </li>
                            </ul>
                            <div class="others-options d-flex align-items-center">
                                <div class="optional-item">
                                    <a href="<?php echo e(route('front.jobs')); ?>" class="default-btn border-radius-5"><?php echo e(__('site.jobs')); ?> <i
                                            class="ri-briefcase-2-line"></i></a>
                                </div>
                                <div class="optional-item">
                                    <a href="<?php echo e(route('front.employmment')); ?>" class="default-btn border-radius-5"><?php echo e(__('site.emp')); ?> <i
                                            class="ri-user-3-line"></i></a>
                                </div>
                            </div>

                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
<?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>