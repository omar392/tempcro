<?php echo jquery(); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
 <!-- jQuery  -->
 <script src="<?php echo e(asset('dashboard/assets_ar/js/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('dashboard/assets_ar/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('dashboard/assets_ar/js/metismenu.min.js')); ?>"></script>
 <script src="<?php echo e(asset('dashboard/assets_ar/js/jquery.slimscroll.js')); ?>"></script>
 <script src="<?php echo e(asset('dashboard/assets_ar/js/waves.min.js')); ?>"></script>

 <!-- App js -->
 <script src="<?php echo e(asset('dashboard/assets_ar/js/app.js')); ?>"></script>
<!-- Required datatable js -->
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Buttons examples -->
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/buttons.colVis.min.js')); ?>"></script>
<!-- Responsive examples -->
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets_ar/datatables/responsive.bootstrap4.min.js')); ?>"></script>



<!-- Datatable init js -->


<?php echo $__env->yieldPushContent('js'); ?>


<?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>