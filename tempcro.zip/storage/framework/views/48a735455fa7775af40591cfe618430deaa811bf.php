    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php if(app()->getLocale() == 'ar'): ?>
       <!-- Bootstrap RTL CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.rtl.min.css')); ?>">
        <?php endif; ?>

        <?php if(app()->getLocale() == 'en'): ?>
       <!-- Bootstrap RTL CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
        <?php endif; ?>
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.min.css')); ?>">
        <!-- Remixicon CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/fonts/remixicon.css')); ?>">
        <!-- Owl Carousel Min CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.theme.default.min.css')); ?>">
        <!-- Metismenu CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/metismenu.min.css')); ?>">
        <!-- Simplebar CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/simplebar.min.css')); ?>">
        <!-- Dropzone CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/dropzone.min.css')); ?>">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
        <!-- Odometer CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/odometer.min.css')); ?>">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/meanmenu.min.css')); ?>">
        <!-- Style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
        <!-- Theme Dark CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/theme-dark.css')); ?>">
        <?php if(app()->getLocale() == 'ar'): ?>
        <!-- RTL CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/rtl.css')); ?>">
        <?php endif; ?>

        
        <meta charset="UTF-8">
<meta name="theme-color" content="#e25448">
<meta name="description" content="<?php echo e($seo->description); ?>">
<meta name="keywords" content="<?php echo e($seo->key); ?>">
<meta name="author" content="Omar">
<meta name="copyrights" content="Omar">
<meta name="robots" content="noindex, nofollow">
<link rel="canonical" href="<?php echo e($seo->url); ?>">
<link rel="prev" href="<?php echo e($seo->url); ?>">
<link rel="next" href="<?php echo e($seo->url); ?>">
<link rel="alternate" href="<?php echo e($seo->url); ?>" hreflang="ar">
<link rel="alternate" href="<?php echo e($seo->url); ?>" hreflang="en-us">
<meta property="og:url" content="<?php echo e(route('front.home')); ?>">
<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo e($seo->title); ?>">
<meta property="og:description" content="<?php echo e($seo->description); ?>">
<meta property="og:locale" content="en">
<meta property="og:locale:alternate" content="ar">
<meta property="og:locale:alternate" content="en_US">
<meta property="og:image" content="<?php echo e(asset('dashboard/' . $setting->image)); ?>">
<meta property="twitter:card" content="<?php echo e($seo->description); ?>">
<meta property="twitter:title" content="<?php echo e($seo->title); ?>">
<meta property="twitter:description" content="<?php echo e($seo->description); ?>">
<meta property="twitter:image" content="<?php echo e(asset('dashboard/' . $setting->image)); ?>">
        
        <title><?php echo e($setting->name); ?> <?php echo $__env->yieldContent('title'); ?></title>
          <?php echo toastr_css(); ?>

        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('frontend/assets/images/30-30.png')); ?>">
    </head>
<?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>