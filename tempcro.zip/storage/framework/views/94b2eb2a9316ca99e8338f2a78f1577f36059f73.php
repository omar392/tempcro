<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Employment Order From The Website</title>
</head>
<body>

        <p>Dears, My Name Is : <?php echo e($details['name']); ?></p> <br>
        <p>Birth Date Is : <?php echo e($details['date']); ?></p><br>
        <p>Phone Is : <?php echo e($details['phone']); ?> , My Age : <?php echo e($details['age']); ?></p><br>
        <p>My Passport Id Is : <?php echo e($details['passport_id']); ?></p><br>
        <p>My National Id Is : <?php echo e($details['national_id']); ?>, Place Of Residence: <?php echo e($details['place_of_residence']); ?></p><br>
        <p>NEXT OF KIN'S INFORMATION</p><br>
        <p>My Name : <?php echo e($details['alt_name']); ?></p><br>
        <p>Phone : <?php echo e($details['alt_phone']); ?></p><br>
        </div>
        
        <div style="width:90%; margin:0 auto; padding-top:15px;font-family: Arial, Helvetica, sans-serif;font-size: large;margin-bottom:50px;">
          <p>Please treat email with care - not reply email</p>
        </div>


</body>
</html>
<?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/mail/offers.blade.php ENDPATH**/ ?>