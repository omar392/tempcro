<?php $__env->startSection('content'); ?>


<div class="content">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title"><?php echo e(__('admin.abouts')); ?></h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('adminhome')); ?>"><?php echo e(__('admin.home')); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e(__('admin.abouts')); ?></li>
                    </ol>
                </div>
            </div> <!-- end row -->
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <form action="" id="abouts" method="POST" data-parsley-validate>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="aboutId" id="about_id" value="<?php echo e($about->id); ?>" class="form-control">

                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.mission_ar')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="mission_ar" id="" cols="10" rows="10"><?php echo $about->mission_ar; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.mission_en')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="mission_en" id="" cols="10" rows="10"><?php echo $about->mission_en; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.vision_ar')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="vision_ar" id="" cols="10" rows="10"><?php echo $about->vision_ar; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.vision_en')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="vision_en" id="" cols="10" rows="10"><?php echo $about->vision_en; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.about_ar')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="about_ar" id="" cols="10" rows="10"><?php echo $about->about_ar; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.about_en')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="about_en" id="" cols="10" rows="10"><?php echo $about->about_en; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.goals_ar')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="goals_ar" id="" cols="10" rows="10"><?php echo $about->goals_ar; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label"><?php echo e(__('admin.goals_en')); ?></label>
                                    <div class="col-sm-10">
                                     <textarea class="form-control"  name="goals_en" id="" cols="10" rows="10"><?php echo $about->goals_en; ?></textarea>
                                    </div>
                                </div>

                                <?php if(Auth::guard('admin')->user()->hasPermission('abouts-update')): ?>
                                <div class="form-group text-center m-t-20">
                                    <div class="col-12">
                                        <button class="btn btn-primary btn-block btn-lg" name="submit"
                                            type="submit"><?php echo e(__('admin.edit')); ?></button>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
                <a href="<?php echo e(url()->previous()); ?>">
                    <button class="btn btn-primary"><?php echo e(__('admin.return')); ?> <i class="fas fa-backward"></i></button>
                </a>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('body').on('submit','#abouts',function (e) {
                e.preventDefault();
                //  alert('no problem');
                 let id = $('#about_id').val();
                 var url = '<?php echo e(route('abouts.update', ':id')); ?>';
                 url = url.replace(':id', id);
                $.ajax({
                    url: url,
                    method: "post",
                    data: new FormData(this),
                    dataType: 'json',
                    cache       : false,
                    contentType : false,
                    processData : false,

                    success: function (response) {
                        // console.log(response);
                        if(response.status == 'success'){
                            toastr.options = {
                            "closeButton": true,
                            "progressBar": true,
                            "showDuration": 500,
                            // "rtl": isRtl
                        }
                        toastr['info']("<?php echo e(__('admin.updatedsuccess')); ?>");
                        }
                    },

                });
            });

        });
 </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>