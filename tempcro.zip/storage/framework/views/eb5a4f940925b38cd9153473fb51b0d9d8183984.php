        <!-- Employers CV Area -->
        <div class="employers-cv-area">
            <div class="container">
                <div class="employers-cv-bg">
                    <div class="row align-items-center">
                        <div class="col-lg-8">
                            <div class="employers-cv-content">
                                <h2><?php echo e(__('site.contact')); ?></h2>
                                <div class="bar"></div>
                                <p><?php echo e(__('site.contactdetails')); ?></p>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="employers-cv-btn">
                                <a href="mailto:<?php echo e($setting->sub_mail); ?>"><?php echo e(__('site.subscripe')); ?> <?php echo e(__('site.email')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Employers CV Area -->
        <!-- Footer Area -->
        <footer class="footer-area">
            <div class="container">
                <div class="footer-top pt-100 pb-70">
                    <div class="row">
                        <div class="col-lg-4 col-sm-6 col-md-6">
                            <div class="footer-widget">
                                <div class="footer-logo">
                                    <a href="<?php echo e(route('front.home')); ?>">
                                        <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="footer-logo1"
                                            alt="Footer Logo">
                                        <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="footer-logo2"
                                            alt="Footer Logo">
                                    </a>
                                </div>

                                <ul class="footer-contact-list">
                                    <li>
                                        <i class="ri-map-pin-line"></i>
                                        <div class="content">
                                            <a>
                                                <?php echo e($setting->address); ?>

                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <i class="ri-mail-line"></i>
                                        <div class="content">
                                            <a href="mailto:<?php echo e($setting->email); ?>">
                                                <?php echo e($setting->email); ?>

                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <i class="ri-phone-line"></i>
                                        <div class="content">
                                            <a href="tel:<?php echo e($setting->phone); ?>">
                                                <?php echo e($setting->phone); ?>

                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-sm-6 col-md-6">
                            <div class="footer-widget">
                                <h3><?php echo e(__('site.quick')); ?></h3>
                                <ul class="footer-list">
                                    <li>
                                        <a href="<?php echo e(route('front.home')); ?>">
                                            <?php echo e(__('site.home')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.about')); ?>">
                                            <?php echo e(__('site.about')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.jobs')); ?>">
                                            <?php echo e(__('site.jobs')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.employmment')); ?>">
                                            <?php echo e(__('site.emp')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.faqs')); ?>">
                                            <?php echo e(__('site.faq')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.contact')); ?>">
                                            <?php echo e(__('site.contact')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.gallery')); ?>" >
                                            <?php echo e(__('site.gallery')); ?>

                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-sm-6 col-md-4">
                            <div class="footer-widget ps-5">
                                <h3><?php echo e(__('site.services')); ?></h3>
                                <ul class="footer-list">

                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a
                                                href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>">
                                                <?php echo e($item->title); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>

            <div class="copyright-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-7">
                            <div class="copy-right-text">
                                <p>
                                    All Rights Reserved <i class="bx bx-copyright"></i><?php echo e(now()->year); ?>

                                    <a href="<?php echo e(route('front.home')); ?>" target="_blank"> Joud Tech</a>
                                </p>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-5">
                            <div class="copy-right-social-link">
                                <ul class="social-link">
                                    <li>
                                        <a href="<?php echo e($setting->facebook); ?>" target="_blank">
                                            <i class="ri-snapchat-fill"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e($setting->instagram); ?>" target="_blank">
                                            <i class="ri-instagram-fill"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e($setting->twitter); ?>" target="_blank">
                                            <i class="ri-twitter-fill"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e($setting->linkedin); ?>" target="_blank">
                                            <i class="ri-linkedin-fill"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->
<?php /**PATH C:\Users\dell\Desktop\tempcro\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>