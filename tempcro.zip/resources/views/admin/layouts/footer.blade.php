<footer class="footer">
    {{ now()->year }} <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Joud Tech</span>.
</footer>
