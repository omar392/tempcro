@jquery
@toastr_js
@toastr_render
 <!-- jQuery  -->
 <script src="{{asset('dashboard/assets_ar/js/jquery.min.js')}}"></script>
 <script src="{{asset('dashboard/assets_ar/js/bootstrap.bundle.min.js')}}"></script>
 <script src="{{asset('dashboard/assets_ar/js/metismenu.min.js')}}"></script>
 <script src="{{asset('dashboard/assets_ar/js/jquery.slimscroll.js')}}"></script>
 <script src="{{asset('dashboard/assets_ar/js/waves.min.js')}}"></script>

 <!-- App js -->
 <script src="{{asset('dashboard/assets_ar/js/app.js')}}"></script>
<!-- Required datatable js -->
<script src="{{asset('dashboard/assets_ar/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{asset('dashboard/assets_ar/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/jszip.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/pdfmake.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/vfs_fonts.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/buttons.html5.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/buttons.print.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{asset('dashboard/assets_ar/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('dashboard/assets_ar/datatables/responsive.bootstrap4.min.js')}}"></script>

{{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> --}}
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> --}}
<!-- Datatable init js -->
{{-- <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script> --}}
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script> --}}
@stack('js')


